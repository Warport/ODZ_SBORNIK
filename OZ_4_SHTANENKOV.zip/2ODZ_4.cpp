#include <iostream>
#include <cmath>

int main() {
    std::cout << "=== Задание 2: Вычисление суммы корней ===\n\n";
    std::cout << "Вычисляем сумму: sqrt(3) + sqrt(6) + ... + sqrt(99)\n\n";
    
    double sum = 0.0;
    
    // Цикл от 3 до 99 с шагом 3
    for (int i = 3; i <= 99; i += 3) {
        double root = sqrt(i);
        sum += root;
        std::cout << "sqrt(" << i << ") = " << root << "\n";
    }
    
    std::cout << "\nОбщая сумма = " << sum << "\n";
    
    return 0;
}
#include <iostream>

int main() {
    std::cout << "=== Задание 1: Вычисление 10! тремя видами циклов ===\n\n";
    
    // 1. Цикл for
    long long factorial_for = 1;
    for (int i = 1; i <= 10; ++i) {
        factorial_for *= i;
    }
    std::cout << "1. Цикл for: 10! = " << factorial_for << "\n";
    
    // 2. Цикл while
    long long factorial_while = 1;
    int i_while = 1;
    while (i_while <= 10) {
        factorial_while *= i_while;
        ++i_while;
    }
    std::cout << "2. Цикл while: 10! = " << factorial_while << "\n";
    
    // 3. Цикл do-while
    long long factorial_do_while = 1;
    int i_do = 1;
    do {
        factorial_do_while *= i_do;
        ++i_do;
    } while (i_do <= 10);
    std::cout << "3. Цикл do-while: 10! = " << factorial_do_while << "\n";
    
    return 0;
}
#include <iostream>
#include <cmath>

int main() {
    std::cout << "=== Задание 3: Последовательность sin ===\n\n";
    std::cout << "Ищем первое число в последовательности:\n";
    std::cout << "sin(x), sin(sin(x)), sin(sin(sin(x))), ...\n";
    std::cout << "которое меньше 0.0001 по модулю\n\n";
    
    double x;
    std::cout << "Введите значение x (в радианах): ";
    std::cin >> x;
    
    double current_value = sin(x);
    int step = 1;
    
    std::cout << "\nШаг " << step << ": sin(x) = " << current_value << "\n";
    
    // Продолжаем пока значение по модулю >= 0.0001
    while (fabs(current_value) >= 0.0001) {
        current_value = sin(current_value);
        step++;
        std::cout << "Шаг " << step << ": sin(...) = " << current_value << "\n";
        
        // Защита от бесконечного цикла
        if (step > 1000) {
            std::cout << "\nПревышено максимальное количество итераций!\n";
            break;
        }
    }
    
    std::cout << "\nРЕЗУЛЬТАТ:\n";
    std::cout << "Первое значение < 0.0001: " << current_value << "\n";
    std::cout << "Получено на шаге: " << step << "\n";
    
    return 0;
}
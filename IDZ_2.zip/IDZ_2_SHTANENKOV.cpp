#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

void task1() {
    double v1, a1, v2, a2, S;
    
    cin >> v1 >> a1 >> v2 >> a2 >> S;
    
    double A = (a1 + a2) / 2;
    double V = v1 + v2;
    
    if (A == 0) {
        if (V > 0) {
            double t = S / V;
            cout << t << endl;
        } else {
            cout << "Встреча невозможна" << endl;
        }
    } else {
        double D = V * V + 4 * A * S;
        
        if (D < 0) {
            cout << "Встреча невозможна" << endl;
        } else {
            double t1 = (-V + sqrt(D)) / (2 * A);
            double t2 = (-V - sqrt(D)) / (2 * A);
            
            double t = -1;
            if (t1 > 0 && t2 > 0) {
                t = (t1 < t2) ? t1 : t2;
            } else if (t1 > 0) {
                t = t1;
            } else if (t2 > 0) {
                t = t2;
            }
            
            if (t > 0) {
                cout << t << endl;
            } else {
                cout << "Встреча невозможна" << endl;
            }
        }
    }
}

void task2() {
    double a;
    
    ifstream fin("in2.dat");
    if (!fin) {
        cout << "Ошибка файла" << endl;
        return;
    }
    fin >> a;
    fin.close();
    
    cout << "Входные данные: " << a << endl;
    
    double a2 = a * a;
    double a4 = a2 * a2;
    double a5 = a4 * a;
    double a10 = a5 * a5;
    
    cout << "Результат: " << a10 << endl;
}

void task3() {
    double x, y, z;
    
    ifstream fin("in3.dat");
    if (!fin) {
        cout << "Ошибка файла" << endl;
        return;
    }
    fin >> x >> y >> z;
    fin.close();
    
    cout << "Входные данные: " << x << " " << y << " " << z << endl;
    
    double sqrt_x = sqrt(abs(x));
    double chisl = y - sqrt_x;
    double znam = z + x * x / 4;
    
    double a;
    if (znam == 0) {
        a = 0;
    } else {
        double drob = chisl / znam;
        a = log(abs(drob));
    }
    
    double b = x - (x * x) / 6.0 + (x * x * x * x * x) / 120.0;
    
    ofstream fout("out3.dat");
    if (!fout) {
        cout << "Ошибка файла" << endl;
        return;
    }
    
    fout << "a = " << a << endl;
    fout << "b = " << b << endl;
    fout.close();
    
    cout << "Результаты в out3.dat" << endl;
}

int main() {
    int choice;
    
    cout << "Выберите задачу (1-3): ";
    cin >> choice;
    
    if (choice == 1) {
        task1();
    } else if (choice == 2) {
        task2();
    } else if (choice == 3) {
        task3();
    } else {
        cout << "Неверный выбор" << endl;
    }
    
    return 0;
}
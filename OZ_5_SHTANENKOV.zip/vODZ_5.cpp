#include <iostream>
#include <cmath>

int main() {
    double x, eps;
    
    std::cout << "Введите значение x (|x| < 1): ";
    std::cin >> x;
    
    if (std::abs(x) >= 1) {
        std::cout << "Ошибка: |x| должно быть меньше 1!\n";
        return 1;
    }
    
    std::cout << "Введите точность eps: ";
    std::cin >> eps;
    
    if (eps <= 0) {
        std::cout << "Ошибка: точность должна быть больше 0!\n";
        return 1;
    }
    
    double sum = x;
    double term = x;
    int n = 2;
    
    while (std::abs(term) >= eps) {
        term = term * (-x) * (n - 1) / n;
        sum += term;
        n++;
    }
    
    std::cout << "\nРезультат: ln(1+" << x << ") ≈ " << sum << "\n";
    std::cout << "Итераций: " << (n - 2) << "\n";
    std::cout << "Точность: " << eps << "\n";
    
    return 0;
}
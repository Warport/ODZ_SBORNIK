#include <iostream>
#include <cmath>

int main() {
    double x, eps;
    
    std::cout << "Введите значение x: ";
    std::cin >> x;
    
    std::cout << "Введите точность eps: ";
    std::cin >> eps;
    
    if (eps <= 0) {
        std::cout << "Ошибка: точность должна быть больше 0!\n";
        return 1;
    }
    
    double sum = 1.0;
    double term = 1.0;
    int n = 1;
    
    while (std::abs(term) >= eps) {
        term = term * x / n;
        sum += term;
        n++;
    }
    
    std::cout << "\nРезультат: e^" << x << " ≈ " << sum << "\n";
    std::cout << "Итераций: " << (n - 1) << "\n";
    std::cout << "Точность: " << eps << "\n";
    
    return 0;
}